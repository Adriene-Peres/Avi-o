public class Assento {
    private int num;
    private char posicao;

    public Assento(int n, char p) {
        num = n;
        posicao = p;
    }

    public int getNum() {
        return num;
    }

    public char getPosicao() {
        return posicao;
    }
}